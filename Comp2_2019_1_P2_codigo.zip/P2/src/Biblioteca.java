import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Biblioteca {

    /** quantidade mínima de cópias de um livro que precisam existir nas estantes da biblioteca para
        que o livro possa ser emprestado */
    public static final int MIN_COPIAS_PARA_PODER_EMPRESTAR = 2;

    /** quantidade máxima de livros da biblioteca que podem estar emprestados, a qualquer tempo, a um mesmo usuário */
    public static final int MAX_LIVROS_DEVIDOS = 3;

    private Map<Livro, Integer> quantVolumesDisponiveisByLivro;
    private int totalVolumesDisponiveis;

    private Map<Long, Usuario> usuarioByCpf;
    private Map<Usuario, List<Livro>> emprestimosByUsuario;

    public Biblioteca() {
        this.quantVolumesDisponiveisByLivro = new HashMap<>();
        this.totalVolumesDisponiveis = 0;
        this.usuarioByCpf = new HashMap<>();
        this.emprestimosByUsuario = new HashMap<>();
    }

    /**
     * Cadastra um usuário. Caso o usuário já exista, atualiza seu nome e seu endereço.
     *
     * @param usuario o usuário a ser inserido/atualizado.
     */
    public void cadastrarUsuario(Usuario usuario) {
        long cpf = usuario.getCpf();
        Usuario usuarioJaExistente = this.usuarioByCpf.get(cpf);
        if (usuarioJaExistente != null) {
            usuarioJaExistente.setNome(usuario.getNome());
            usuarioJaExistente.setEndereco(usuario.getEndereco());
        } else {
            this.usuarioByCpf.put(cpf, usuario);
        }
    }

    /**
     * Retorna um usuário previamente cadastrado, a partir do CPF informado.
     *
     * @param cpf o CPF do usuário desejado
     * @return o usuário, caso exista; ou null, caso não exista nenhum usuário cadastrado com aquele CPF
     */
    public Usuario getUsuario(long cpf) {
        return this.usuarioByCpf.get(cpf);
    }

    /**
     * @return o número total de usuários cadastrados na biblioteca
     */
    public int getTotalDeUsuariosCadastrados() {
        return this.usuarioByCpf.size();
    }

    /**
     * Adquire `quantidade` cópias do livro informado para o acervo da biblioteca.
     *
     * @param livro o livro sendo adquirido
     * @param quantidade o número de cópias do livro sendo adquiridas
     */
    public void adquirirLivro(Livro livro, int quantidade) {
        this.quantVolumesDisponiveisByLivro.put(livro,
                this.quantVolumesDisponiveisByLivro.getOrDefault(livro, 0) + quantidade);
        this.totalVolumesDisponiveis += quantidade;
    }

    /**
     * Empresta um livro para um usuário da biblioteca.
     *
     * @param livro o livro a ser emprestado
     * @param usuario o usuário que está pegando emprestado o livro
     *
     * @return true, se o empréstimo foi bem-sucedido;
     *         false, se o livro não está disponível para empréstimo
     *         (IMPORTANTE: um livro é considerado disponível para empréstimo se há pelo menos
     *                      Biblioteca.MIN_COPIAS_PARA_PODER_EMPRESTAR cópias daquele livro nas estantes da biblioteca;
     *                      isto é, as estantes da biblioteca jamais poderão ficar com menos do que
     *                      Biblioteca.MIN_COPIAS_PARA_PODER_EMPRESTAR-1 cópias de qualquer livro de seu acervo)
     *
     * @throws UsuarioNaoCadastradoException se o usuário informado não está cadastrado na biblioteca
     * @throws LimiteEmprestimosExcedidoException se o usuário já está com muitos livros emprestados no momento
     */
    public boolean emprestarLivro(Livro livro, Usuario usuario)
            throws UsuarioNaoCadastradoException, LimiteEmprestimosExcedidoException {

        if (this.usuarioByCpf.get(usuario.getCpf()) == null) {
            throw new UsuarioNaoCadastradoException();
        }

        List<Livro> livrosEmprestadosComEsseUsuario = this.emprestimosByUsuario.get(usuario);
        if (livrosEmprestadosComEsseUsuario != null && livrosEmprestadosComEsseUsuario.size() >= MAX_LIVROS_DEVIDOS) {
            throw new LimiteEmprestimosExcedidoException();
        }

        int quantidadeDisponivel = this.quantVolumesDisponiveisByLivro.getOrDefault(livro, 0);
        if (quantidadeDisponivel < MIN_COPIAS_PARA_PODER_EMPRESTAR) {
            return false;
        }

        if (livrosEmprestadosComEsseUsuario == null) {
            livrosEmprestadosComEsseUsuario = new ArrayList<>();  // lazy instantiation
            this.emprestimosByUsuario.put(usuario, livrosEmprestadosComEsseUsuario);
        }
        // anota o novo livro sendo emprestado àquele usuário
        livrosEmprestadosComEsseUsuario.add(livro);

        // diminui a quantidade de cópias disponiveis do livro que está sendo emprestado
        this.quantVolumesDisponiveisByLivro.put(livro, quantidadeDisponivel - 1);
        this.totalVolumesDisponiveis--;

        return true;
    }

    /**
     * Recebe de volta um livro que havia sido emprestado.
     *
     * @param livro o livro sendo devolvido
     * @param usuario o usuário que havia tomado emprestado aquele livro
     *
     * @throws DevolucaoInvalidaException se o livro informado não se encontra emprestado para o usuário informado
     */
    public void receberDevolucaoLivro(Livro livro, Usuario usuario) throws DevolucaoInvalidaException {
        List<Livro> livrosEmprestadosComEsseUsuario = this.emprestimosByUsuario.get(usuario);
        if (livrosEmprestadosComEsseUsuario == null || !livrosEmprestadosComEsseUsuario.contains(livro)) {
            throw new DevolucaoInvalidaException();
        }
        livrosEmprestadosComEsseUsuario.remove(livro);
        this.quantVolumesDisponiveisByLivro.put(livro, quantVolumesDisponiveisByLivro.get(livro) + 1);
        this.totalVolumesDisponiveis++;
    }

    /**
     * Retorna a quantidade de livros emprestados ao usuário informado.
     *
     * @param usuario o usuário desejado
     * @return a quantidade de livros emprestados àquele usuário; caso o usuário não esteja devendo nenhum livro,
     *         ou não seja nem mesmo um usuário cadastrado na biblioteca, retorna zero, não deve nada
     */
    public int getQuantidadeDeLivrosDevidos(Usuario usuario) {
        List<Livro> livrosEmprestadosComEsseUsuario = this.emprestimosByUsuario.get(usuario);
        return livrosEmprestadosComEsseUsuario == null ? 0 : livrosEmprestadosComEsseUsuario.size();
    }

    /**
     * @return a quantidade total de livros nas estantes da biblioteca (isto é, a soma das quantidades de cópias
     *         não-emprestadas de todos os livros do acervo da biblioteca).
     */
    public int getQuantidadeDeLivrosNaEstante() {
        return totalVolumesDisponiveis;
    }

    /**
     * Retorna o número de cópias do livro informado que existem na estante da biblioteca
     * (isto é, que não estão emprestados).
     *
     * @param livro o livro desejado
     * @return o número de cópias não-emprestadas daquele livro
     */
    public int getQuantidadeDeLivrosNaEstante(Livro livro) {
        return this.quantVolumesDisponiveisByLivro.getOrDefault(livro, 0);
    }
}
