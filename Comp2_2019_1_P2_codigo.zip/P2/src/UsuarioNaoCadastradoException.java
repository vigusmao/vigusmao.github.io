public class UsuarioNaoCadastradoException extends Exception {
}
    