public class DevolucaoInvalidaException extends Exception {
}
