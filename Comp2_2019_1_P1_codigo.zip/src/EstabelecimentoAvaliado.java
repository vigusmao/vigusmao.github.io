public abstract class EstabelecimentoAvaliado extends Estabelecimento implements Avaliado {

    public EstabelecimentoAvaliado(String nome) {
        super(nome);
    }
}
