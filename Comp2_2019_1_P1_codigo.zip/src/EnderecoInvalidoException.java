public class EnderecoInvalidoException extends Exception {

    public EnderecoInvalidoException(String msg) {
        super(msg);
    }
}
