public interface Avaliado {

    /**
     * @return um inteiro, de 1 a 5, indicando a quantidade de estrelas
     * referentes à qualidade de algo (segundo algum tipo de avaliação)
     */
    int getAvaliacao();
}
